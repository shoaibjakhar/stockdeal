"use strict";

$(document).ready(function() {
  var winHeight = $(window).height();	
		//alert(winHeight)
		$('.home').height(winHeight);
 
 
   $('#toggleMenu1').click(function() {
	   $(this).hide();
	   $('#toggleMenu2').show();
	   $('.sidebar').hide();
	   $('.main_container').css({'width':'99%'});
 	   
	  
	  
   }); 

   $('#toggleMenu2').click(function() {
	   $(this).hide();
	   $('#toggleMenu1').show();
	   $('.sidebar').show();
	   $('.main_container').css({'width':'79%'});
   });
 
 
 });
 
 
 