<?php
session_start();
?>

<a href="logout.php">LOGOUT</a>

<?php echo('Hello world') ?>