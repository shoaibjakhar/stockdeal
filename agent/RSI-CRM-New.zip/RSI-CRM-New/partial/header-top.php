<?php date_default_timezone_set('Asia/Kolkata'); ?>

<div id="show_birth_day_notification"></div>
<script>
   
    
   


    $("#show_birth_day_notification").load('Ajax_files/birth_day_notification.php');
</script>


<!-- follow up notif-wrap -->
<?php


$DateTimeINR = date("Y-m-d H:i:s");

//echo($DateTimeINR);
	
$sql="SELECT id, DATE_FORMAT( DateTime, '%d/%m/%Y %h:%i %p' ) AS DateTime, Full_Name, Email, Mobile, Disposition, Remark, UserName, DATE_FORMAT( FowllowUpDateTime, '%d-%m-%Y %h:%i' ) AS FowllowUpDateTime , DATE_FORMAT( FowllowUpDateTime, '%d/%m/%Y' ) AS FowllowUpDate, DATE_FORMAT( FowllowUpDateTime, '%H' ) AS FowllowUpTime, DATE_FORMAT( FowllowUpDateTime, '%p') AS FowllowUpTimeAM_PM, State, Priority, Segment FROM FolllowUpLeads WHERE FowllowUpDateTime <= '".$DateTimeINR."' AND UserName ='".$username."' AND NOT Status='Done' AND NOT Disposition='NT' AND NOT Disposition='NI' AND NOT Disposition='CT' AND NOT Disposition='LB' AND NOT Disposition='DND' AND NOT Disposition='WN' AND NOT Disposition='DC' AND NOT Disposition='Sale' AND NOT Disposition='NCD' AND NOT FowllowUpDateTime='0000-00-00 00:00:00' AND FowllowUpDateTime >= DATE_FORMAT(CURDATE(), '%Y-%m-01') - INTERVAL 2 MONTH ORDER BY `FolllowUpLeads`.`FowllowUpDateTime` DESC LIMIT 0 , 1";
	
	
$result = mysqli_query($connect,$sql);


	
while($row = mysqli_fetch_array($result))
  {
	
	echo('<div class="follow-up-notif-wrap">');
	echo('<div class="follow-up-notif">');
	echo('<div class="follow-up notice-danger">');
	echo('<div class="follow-up-notif">');
	echo('<div class="infotab">');
echo('<form action="notification-update.php" method="GET">');
	echo('<table class="table table-fit" style="margin:0 0 0 40px;padding:0;"><tbody>
	   <tr><td style="vertical-align: top;display:none">
               <span class="number">105</span>
            </td>
	     
            <td>
               <div class="head">Follow Up</div>
               <div class="content">'.$row['FowllowUpDateTime'].'</div>
            </td>
            <td>
               <div class="head">Name</div>
               <div class="content">'.$row['Full_Name'].'<input type="hidden" name="Id_Notification" value="'.$row['id'].'"/></div>
            </td>
			 <td>
               <div class="head">Mobile</div>
               <div class="content">



			   <a class="" href="'.'disposition.php?Mobile='.$row['Mobile'].'&UserName='.$username.'&FollowUpId='.$row['id'].'&Full_Name='.$row['Full_Name'].'">'.$row['Mobile'].'</a></div>
            </td>
            <td>
               <div class="head">Disposition</div>
               <div class="content">'.$row['Disposition'].'</div>
            </td>
			<td>
               <div class="head">Segment</div>
               <div class="content">'.$row['Segment'].'</div>
            </td>
            <td>
               <div class="head">Remarks</div>
               <div class="content"><textarea style="width:380px;">'.$row['Remark'].'</textarea></div>
            </td>
            <td>
               
			   <a class="btn btn-success" href="'.'disposition.php?Mobile='.$row['Mobile'].'&UserName='.$username.'&FollowUpId='.$row['id'].'">Update</a>
            </td>
            <td>
               <button type="submit" class="btn btn-info purple">Remind Me Later</button>
            </td>
			 <td>
               <div class="head">Date</div>
               <div class="form-group">
                  <input type="text" style="width:120px;" class="form-control disableNow" id="Follow_Up_Reminder_datepicker_INR" placeholder="Date" autocomplete="off" required>

                        <input type="hidden" class="form-control" id="Follow_Up_Reminder_datepicker" name="Follow_Up_Reminder_datepicker" placeholder="Date">
						</div>
            </td>
			 <td>
               <div class="head">Hour</div>
               <div class=""><select id="Hour" name="Hour" class="disableNow form-control" style="width:70px;" required>
                       <option value="" disabled selected>H</option>	
                       <option value="01">01</option>	
                       <option value="02">02</option>	
                       <option value="03">03</option>	
                       <option value="04">04</option>	
                       <option value="05">05</option>	
                       <option value="06">06</option>	
                       <option value="07">07</option>	
                       <option value="08">08</option>	
                       <option value="09">09</option>	
                       <option value="10">10</option>	
                       <option value="11">11</option>	
                       <option value="12">12</option>	
                       <option value="13">13</option>	
                       <option value="14">14</option>	
                       <option value="15">15</option>	
                       <option value="16">16</option>	
                       <option value="17">17</option>	
                       <option value="18">18</option>	
                       <option value="19">19</option>	
                       <option value="20">20</option>	
                       <option value="21">21</option>	
                       <option value="22">22</option>	
                       <option value="23">23</option>	


        </select></div>
            </td>
			 <td>
               <div class="head">Minuts</div>
               <div class="">				
		 <select id="Minuts" name="Minuts" class="disableNow form-control" style="width:70px;" required>
<option value="" disabled selected>M</option>	
                       <option value="01">01</option>	
                       <option value="02">02</option>	
                       <option value="03">03</option>	
                       <option value="04">04</option>	
                       <option value="05">05</option>	
                       <option value="06">06</option>	
                       <option value="07">07</option>	
                       <option value="08">08</option>	
                       <option value="09">09</option>	
                       <option value="10">10</option>	
                       <option value="11">11</option>	
                       <option value="12">12</option>	
                       <option value="13">13</option>	
                       <option value="14">14</option>	
                       <option value="15">15</option>	
                       <option value="16">16</option>	
                       <option value="17">17</option>	
                       <option value="18">18</option>	
                       <option value="19">19</option>	
                       <option value="20">20</option>	
                       <option value="21">21</option>	
                       <option value="22">22</option>	
                       <option value="23">23</option>	
                       <option value="24">24</option>	
                       <option value="25">25</option>	
                       <option value="26">26</option>	
                       <option value="27">27</option>	
                       <option value="28">28</option>	
                       <option value="29">29</option>	
                       <option value="30">30</option>	
                       <option value="31">31</option>	
                       <option value="32">32</option>	
                       <option value="33">33</option>	
                       <option value="34">34</option>	
                       <option value="35">35</option>	
                       <option value="36">36</option>	
                       <option value="37">37</option>	
                       <option value="38">38</option>	
                       <option value="39">39</option>	
                       <option value="40">40</option>	
                       <option value="41">41</option>	
                       <option value="42">42</option>	
                       <option value="43">43</option>	
                       <option value="44">44</option>	
                       <option value="45">45</option>	
                       <option value="46">46</option>	
                       <option value="47">47</option>	
                       <option value="48">48</option>	
                       <option value="49">49</option>	
                       <option value="50">50</option>	
                       <option value="51">51</option>	
                       <option value="52">52</option>	
                       <option value="53">53</option>	
                       <option value="54">54</option>	
                       <option value="55">55</option>	
                       <option value="56">56</option>	
                       <option value="57">57</option>	
                       <option value="58">58</option>	

        </select></div>
            </td>
			
         </tr>
      </tbody>
   </table>');
	echo('</form>');
	echo('</div>');
	echo('</div>');
	echo('</div>');
	echo('</div>');
	echo('</div>');
	
  }




?>				 




<?php
if(isset($_GET['del_notifi'])){
   $usernames = $_GET['ses_user'];
   $result_update = mysqli_query($connect,"UPDATE employee SET read_notification='1' where username = '$usernames' "); 
	
	//$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	//header('location:'.$actual_link);
	header('location:memberpage.php');
}
if(isset($_GET['del_notifi_demo'])){
   $usernames = $_GET['ses_user'];
   $result_update = mysqli_query($connect,"UPDATE employee SET demo_read_notification='1' where username = '$usernames' "); 
	
	//$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	//header('location:'.$actual_link);
	header('location:memberpage.php');
}
?>

		<div class="brand-logo">
	    <?php
	 $result = mysqli_query($connect,"SELECT Company_Name FROM Options WHERE Id = '1'");
         $Company_Name = mysqli_result($result, 0);
			//echo($Login_Logo);
			
	    ?>

<div class="header-top">
  <div class="">
    <div class="col-xs-4">
     <img src="images/menu-1.png" alt="1" title="1" id="toggleMenu1" class="toggle-menu" style="display:none;"/>
     <img src="images/menu-2.png" alt="2" title="2" id="toggleMenu2" class="toggle-menu" style="display:none;"/>
    
	  </div>
    <div class="col-xs-5"><p class="text-center font-size18">Welcome to <?php echo($Company_Name);?> CRM</p></div>
    <div class="col-xs-3"><p class="font-size18 logout"><a href="logout.php">Logout&nbsp; <img src="images/logout.png"/></a></p></div>
  </div>
  <div class="clearfix"></div>
</div>
 
 
 <!-- Stock Tips Notification For Customer -->
 <?php 
 //$username = $_SESSION['username'];
 $sql = ("SELECT st.Ideas, st.Sagment, st.Result FROM stock_tips st,employee e WHERE e.read_notification='0' AND e.username='$username' AND DATE( CURDATE( ) ) = DATE( DateTime) ORDER BY `st`.`Id` DESC LIMIT 1");
 $result = mysqli_query($connect,$sql);
 $data = mysqli_fetch_assoc($result);
 if(mysqli_num_rows($result)>0){
?>
<div class="container-notif-wrap">
<div class="container-notif">
    <div class="notice notice-danger">
        <table style="font-size:16px;">
			<tr>
			 <td style="">SEGMENT</td>
				<td style="padding-left: 30px;">STOCK TIPS</td>
			</tr>
          <tr>
            <td style="font-weight: bold;"><?php echo $data['Sagment']; ?></td>
            <td style="font-weight: bold;display: none;"> 
              <div class="btn <?php echo $data['Result']; ?>" style="margin-top:10px;margin-left:10px;margin-right:10px">
                <?php echo $data['Result']; ?>
              </div>
            </td>
            <td style="font-weight: bold;padding-left: 30px;"><?php echo $data['Ideas']; ?></td>
            <!-- <a href="stock-tips.php" class="btn Open pull-right" style="align:right;">Read</a> -->
            <!-- <input type="submit" name="del_notifi" class="btn btn-primary pull-right" value="delete"> -->
            <form method="GET" action="stock-tips.php">
              <input type="hidden" name="ses_user" value="<?php echo $username;?>">
              <!-- <input type="submit" name="del_notifi" class="btn btn-info pull-left" value="Read" style="margin-right: 15px;"> -->
			  <a href="stock-tips.php" class="btn btn-info pull-left"  style="margin-right: 15px;">Read</a>	
            </form>
            <form method="GET" action="">
              <input type="hidden" name="ses_user" value="<?php echo $username;?>">
              <input type="submit" name="del_notifi" class="btn btn-primary pull-left" value="Close" style="margin-right: 30px;display:none">
            </form>
          </tr>
        </table>
    </div>    
</div>
	</div>
 <!-- For Notice of Segments End -->
 <?php }?>
 <script>
 function delete_noti(){
  //  alert('hellp');
 var request = $.ajax({
  url: "delete_notification.php/index",
  type: "GET",
  dataType: "html"
});
request.done(function(msg) {
  location.reload();
	// setTimeout(function(){  location.reload(); }, 1000);
});}
 </script>
 
 
 <!-- Demo Stock Tips Notification For Customer -->
 <?php 
 //$username = $_SESSION['username'];
 $sql = ("SELECT st.Ideas, st.Sagment, st.Result FROM Demo_Stock_Tips st,employee e WHERE e.demo_read_notification='0' AND e.username='$username' AND DATE( CURDATE( ) ) = DATE( DateTime) ORDER BY `st`.`Id` DESC LIMIT 1");
 //echo $sql; exit;
 $result = mysqli_query($connect,$sql);

 $data = mysqli_fetch_assoc($result);
 if(mysqli_num_rows($result)>0){
?>
<div class="container-notif-wrap">
<div class="container-notif">
    <div class="notice notice-danger">
        <table style="font-size:16px;">
			<tr>
			 <td style="">SEGMENT</td>
				<td style="padding-left: 30px;">STOCK TIPS</td>
			</tr>
          <tr>
            <td style="font-weight: bold;"><?php echo $data['Sagment']; ?></td>
            <td style="font-weight: bold;display: none;"> 
              <div class="btn <?php echo $data['Result']; ?>" style="margin-top:10px;margin-left:10px;margin-right:10px">
                <?php echo $data['Result']; ?>
              </div>
            </td>
            <td style="font-weight: bold;padding-left: 30px;"><?php echo $data['Ideas']; ?></td>
            <!-- <a href="stock-tips.php" class="btn Open pull-right" style="align:right;">Read</a> -->
            <!-- <input type="submit" name="del_notifi" class="btn btn-primary pull-right" value="delete"> -->
            <form method="GET" action="stock-tips.php">
              <input type="hidden" name="ses_user" value="<?php echo $username;?>">
              <!-- <input type="submit" name="del_notifi" class="btn btn-info pull-left" value="Read" style="margin-right: 15px;"> -->
			  <a href="demo-stock-tips.php" class="btn btn-info pull-left"  style="margin-right: 15px;">Read</a>	
            </form>
            <form method="GET" action="" 
              <input type="hidden" name="ses_user" value="<?php echo $username;?>">
              <input type="submit" name="del_notifi_demo" class="btn btn-primary pull-left" value="Close" style="margin-right: 30px;display:none">
            </form>
          </tr>
        </table>
    </div>    
</div>
	</div>
 <!-- For Notice of Segments End -->
 <?php }?>
 <script>
 function delete_noti(){
  //  alert('hellp');
 var request = $.ajax({
  url: "delete_notification.php/index",
  type: "GET",
  dataType: "html"
});
request.done(function(msg) {
  location.reload();
	// setTimeout(function(){  location.reload(); }, 1000);
});}
 </script>



