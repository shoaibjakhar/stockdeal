<?php
if (empty($username)) { //exit;?>
<script> location.href = "index.php"</script>
    
<?php }
else {
	//echo "Have a good day!";
}

?>