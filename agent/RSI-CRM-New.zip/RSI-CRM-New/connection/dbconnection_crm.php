<?php
ob_start();
error_reporting(0);
ini_set('display_errors',0);
$domain_name = $_SERVER['HTTP_HOST'];


// Real Stock Ideas  
if($domain_name == 'crm.rsi-hg-ind.online' || $domain_name == 'www.crm.rsi-hg-ind.online'){

	$connect = mysqli_connect('localhost','rsihgind_RSI','kkb.,&a1fi~h','rsihgind_RSI');
	//$connect = mysqli_connect('db-mysql-blr1-20482-do-user-10692459-0.b.db.ondigitalocean.com:25060','doadmin','iKd5pNhhL1YaDbrE','defaultdb');
	if(!$connect)
	{
	die('Could not connect!' . mysql_error);
	}
}


// Share Advisor
else if($domain_name == 'crm.share-advisor.in.net' || $domain_name == 'www.crm.share-advisor.in.net'){

$connect = mysqli_connect('localhost','shareadv_SA','Hr]W;V+%S2r$','shareadv_SA');
if(!$connect)
 {
die('Could not connect!' . mysql_error);
 }
}

// Stock Advisor
else if($domain_name == 'crm.water-or-air.online' || $domain_name == 'www.crm.water-or-air.online'){

$connect = mysqli_connect('localhost','stockadv_ST','6]6&=6kxM~KY','stockadv_ST');
if(!$connect)
{
die('Could not connect! Stock Advisor' . mysql_error);
}

	
}

// Share Market Ideas
else if($domain_name == 'crm.smartalerts.online' || $domain_name == 'www.crm.smartalerts.online'){
$connect = mysqli_connect('localhost','crmwala_SMI','4b;=gE?yyAx)','crmwala_SMI');
if(!$connect)
{
die('Could not connect!' . mysql_error);
}
	
}


// Shrimoney CRM
else if($domain_name == 'crm.monsoon-or-winter.online' || $domain_name == 'www.crm.monsoon-or-winter.online'){
$connect = mysqli_connect('localhost','hamzah_SHRI','oN-t3%%ZY66c','hamzah_SHRI');
if(!$connect)
{
die('Could not connect!' . mysql_error);
}
	
}









if (!function_exists('mysql_result')) {
  function mysql_result($res, $row, $field=0) {
    return mysqli_result($res, $row, $field=0);
  }
}

if (!function_exists('mysqli_result')) {
  function mysqli_result($res, $row, $field=0) {
    $res->data_seek($row);
    $datarow = $res->fetch_array();
    return $datarow[$field];
  }
}

if (!function_exists('mysql_query')) {
    function mysql_query($query){
        global $connect;
        return mysqli_query($connect,$query);
    }
}

//mysql_fetch_array

if (!function_exists('mysql_fetch_array')) {
    function mysql_fetch_array($query){
        global $connect;
        return mysqli_fetch_array($query);
    }
}
if (!function_exists('mysql_fetch_assoc')) {
    function mysql_fetch_assoc($query){
        global $connect;
        return mysqli_fetch_array($query);
    }
}
if (!function_exists('mysql_close')) {
    function mysql_close($con){
        //global $connect;
        return mysqli_close($con);
    }
}
//mysql_free_result
if (!function_exists('mysql_num_rows')) {
    function mysql_num_rows($query){
        global $connect;
        return mysqli_num_rows($query);
    }
}

if (!function_exists('mysql_free_result')) {
    function mysql_free_result($query){
        global $connect;
        return mysqli_free_result($query);
    }
}

 
?>

