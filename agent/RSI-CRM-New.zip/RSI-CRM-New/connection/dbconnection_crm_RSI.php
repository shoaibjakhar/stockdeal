<?php 
$connect = mysqli_connect('localhost','rsihgind_RSI','kkb.,&a1fi~h','rsihgind_RSI');
	if(!$connect)
	{
	die('Could not connect!' . mysql_error);
	}

?>

