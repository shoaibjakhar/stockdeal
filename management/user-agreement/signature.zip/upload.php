<?php
    
//     $folderPath = "upload/";
  
//     $image_parts = explode(";base64,", $_POST['signed']);
        
//     $image_type_aux = explode("image/", $image_parts[0]);
      
//     $image_type = $image_type_aux[1];
      
//     $image_base64 = base64_decode($image_parts[1]);
      
//     $file = $folderPath . uniqid() . '.'.$image_type;
//     $sql="INSERT INTO images(name) VALUES('$file')";
//     mysqli_query($conn,$sql);
      
//     file_put_contents($file, $image_base64);
//     echo "Signature Uploaded Successfully.";

    include_once 'connection.php';

    $full_name =  $_POST['full_name'];
    $mobile    =   $_POST['mobile'];
    $email     =   $_POST['email'];
    $agent_name =  $_POST['agent_name'];
  
    $folderPath = "upload/";
    $image_parts = explode(";base64,", $_POST['signed']); 
    $image_type_aux = explode("image/", $image_parts[0]);
    $image_type = $image_type_aux[1];
    $image_base64 = base64_decode($image_parts[1]);
    $file = $folderPath . uniqid() . '.'.$image_type;
    echo $file;
     $sql="INSERT INTO image(name,full_name,mobile,agent_name,email) VALUES('$file','$full_name','$mobile','$agent_name','$email')";
     mysqli_query($conn,$sql);
    file_put_contents($file, $image_base64);
    echo "Signature Uploaded Successfully.";

 ?>